from PIL import Image, ImageDraw, ImageFont
import pandas as pd
import os
from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import letter
from io import BytesIO
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

# Function for sending invitation over whatsapp
def send_pdf(driver,contact_name,number, pdf_path,outside):
    try:
        wait = WebDriverWait(driver, 20)
        
        # Search for the contacts chat based on number
        search_box = wait.until(EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true'][@data-tab='3']")))
        search_box.clear()
        search_box.send_keys(number)
        time.sleep(2)
        search_box.send_keys(Keys.ENTER)

        wait.until(EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true'][@data-tab='10']")))

        # Attach and share invitation card
        attach_btn = wait.until(EC.presence_of_element_located((
            By.XPATH, "//*[contains(@aria-label, 'Attach')]"
        )))
        driver.execute_script("arguments[0].click();", attach_btn)

        time.sleep(1)
        
        doc_btn = wait.until(EC.presence_of_element_located((
            By.XPATH, "/html/body/div[1]/div/div/div[1]/div/span[6]/div/ul/div/div/div[1]/li/div/span"
        )))
        driver.execute_script("arguments[0].click();", doc_btn)
           

        time.sleep(1)

        doc_input = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@accept='*']")))
        doc_input.send_keys(os.path.abspath(pdf_path))

        time.sleep(3)
        
        wait.until(EC.presence_of_element_located((
            By.XPATH, "//div[contains(@class, 'copyable-text')]"
        )))

        
        send_btn = wait.until(EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div/span/div/div/div/div[2]/div/div[2]/div[2]/div/div/span')))
        driver.execute_script("arguments[0].style.border='3px solid green'", send_btn)
        driver.execute_script("arguments[0].click();", send_btn)
        
        time.sleep(10)
        
        
        #  Send a text message
        message_box = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((
                By.XPATH,
                '//div[@role="textbox" and @contenteditable="true" and @aria-placeholder="Type a message"]'
            ))
        )
        message = f"Hi {contact_name}, we would love to have you attend my sons wedding. Please RSVP here"
        message_box.click()
    
        actions = ActionChains(driver)
        actions.move_to_element(message_box)
        actions.click()
        actions.send_keys(message)
        actions.send_keys(Keys.ENTER)
        actions.perform()

        
        
        #  Optional: wait to ensure the message sends before quitting
        time.sleep(1)

    except Exception as e:
        print(f"❌ Failed to send to {contact_name}: {e}")


# Function for typing in wrapped text      
def draw_wrapped_text(can, text, position, font_name, font_size, max_width, max_height,
                      line_spacing=0, fill=(150, 75, 0), min_font_size=4):
    x, y_bottom = position

    def wrap_text(words, font_size):
        can.setFont(font_name, font_size)
        lines = []
        line = ''
        for word in words:
            test_line = f"{line} {word}".strip()
            if can.stringWidth(test_line, font_name, font_size) <= max_width:
                line = test_line
            else:
                lines.append(line)
                line = word
        if line:
            lines.append(line)
        return lines

    words = text.split()
    lines = wrap_text(words, font_size)

    #  Try reducing font size until text fits within max_height
    while True:
        line_height = font_size
        total_height = len(lines) * line_height + (len(lines) - 1) * line_spacing
        if total_height <= max_height or font_size <= min_font_size:
            break
        font_size -= 1
        lines = wrap_text(words, font_size)

    #  Set font and fill color
    can.setFont(font_name, font_size)
    can.setFillColorRGB(*[c / 255 for c in fill])

    #  Start from bottom Y and draw lines upward
    current_y = y_bottom + total_height - line_height  #  Top line's baseline

    for line in lines:
        line_width = can.stringWidth(line, font_name, font_size)
        #  center within max_width box starting at x
        can.drawString(x + (max_width - line_width) / 2, current_y, line)
        current_y -= line_height + line_spacing



# Template name
template_path = 'shaadi_invitation_template.pdf'

# Tracker name
excel_path = 'shaadi_guest_list.xlsx'

# Output folder name
output_folder = 'output'
output_pdf_path = 'invitation_modified.pdf'
# Create output folder
os.makedirs(output_folder, exist_ok=True)

# Font file name
font_path = 'weddingdayfont.ttf' 

# Template page sizes, need to adjust as per your card template
page_width = 1240
page_height = 1748

# Register font
pdfmetrics.registerFont(TTFont('MyFont', font_path))

# Set up Chrome and Selenium
options = Options()
user_data_dir = os.path.abspath("User_Data")  #  Converts to full path
options = webdriver.ChromeOptions()
options.add_argument(f"--user-data-dir={user_data_dir}")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-gpu")
options.add_argument("--remote-debugging-port=9222")  #  Helps with DevToolsActivePort issue
options.add_argument("--disable-blink-features=AutomationControlled")  #  Optional: more stealth
# DO NOT add --headless unless you’re trying to run it headless
# Optional: prevent unnecessary logs
options.add_experimental_option('excludeSwitches', ['enable-logging'])
# Use your complete chromedriver path below
driver_path = r"chromedriver.exe"
driver = webdriver.Chrome(service=Service(driver_path), options=options)

# Now go to WhatsApp
driver.get("https://web.whatsapp.com")
input("Scan QR and press Enter to continue once logged in...")

coords = {
    'Name': (55,215),
    'Sangeet': (146, 315),
    'Mehendi': (146, 270),
    'VIP': (146, 225),
    'Haldi': (146, 180),
    'Reception': (146, 135),
    'Nikkah': (106, 36)
}


df = pd.read_excel(excel_path, header=None, skiprows=1)

# Adjust these according to what columns you want to consider
df = df[[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]]
df.columns = ['Name','Male','Female','Total','Sangeet','Mehendi','Reception', 'VIP','Haldi','Nikkah','Number','einvite']


for idx, row in df.iterrows():
    
    # Read original PDF
    reader = PdfReader(template_path)
    writer = PdfWriter()
    
    # Create overlay PDF with only text
    packet = BytesIO()
    can = canvas.Canvas(packet, pagesize=(page_width, page_height))
    
    # Draw on first pdf page
    text=row['Name']
    # Give the maximum height and width according to you template
    draw_wrapped_text(can, text, coords['Name'], 'MyFont',29,192,37)
    
    # Jump 2 pages in the pdf
    can.showPage()
    can.showPage()

    # Adjust logic as per your preferences
    for event in ['VIP','Haldi','Reception','Sangeet','Mehendi','Nikkah']:
        count = row[event]
        
        if event in ['Mehendi']:
            if pd.notna(count) and count == 1:
                if pd.notna(row['Female']):
                    text = f"{row['Female']}"
                else:
                    text = f"Mrs {row['Male']}"
            elif pd.notna(count) and count == row['Total']:
                text = "All" 
            else:
                text = "---"
        else:
            
            if pd.notna(count) and count == row['Total']:
                text = "All"
            elif pd.isna(count) and count == 2:
                if pd.isna(row['Female']):
                    text = f"Mr & Mrs {row['Male']}"
                else:
                    text = f"{row['Male']} & {row['Female']}"
            elif pd.notna(count) and count == 1:
                if pd.isna(row['Female']):
                    text = f"{row['Female']}"
                elif pd.isna(row['Male']):
                    text = f"{row['Male']}"
                else:
                    text = "---"
            else:
                text = "---"
        
        # Give the maximum height and width according to you template
        
        if event=='Nikkah':
            draw_wrapped_text(can, text, coords[event], 'MyFont',24,87,26)
            
        else:
            draw_wrapped_text(can, text, coords[event], 'MyFont',14, 102,30)

    
    can.save()
    packet.seek(0)
    
    # Read overlay PDF from pages 1 and 3
    overlay_pdf = PdfReader(packet) 
    overlay_page1 = overlay_pdf.pages[0]
    overlay_page2 = overlay_pdf.pages[2]
    

    # Merge overlay with the correct pages
    for i, page in enumerate(reader.pages):
        if i == 0:
            page.merge_page(overlay_page1)
        elif i == 2:
            page.merge_page(overlay_page2)
        writer.add_page(page)

    
    # Save final PDF with a desired name
    safe_name = os.path.join(output_folder, str(row['Name']).replace(' ', '_').replace('/', '_') + '.pdf')
    with open(safe_name, "wb") as f_out:
        writer.write(f_out)
    
    # Share e-invitation if marked
    if row['einvite']=='Y':
        send_pdf(driver,row['Name'],row['Number'], safe_name)
    
input("Script complete. Press Enter to close the browser...")
driver.quit()